package com.example.sufiproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SufiProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SufiProjectApplication.class, args);
	}

}
